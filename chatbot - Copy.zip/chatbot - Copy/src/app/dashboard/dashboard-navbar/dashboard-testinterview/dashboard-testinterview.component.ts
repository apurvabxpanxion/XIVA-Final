import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-testinterview',
  templateUrl: './dashboard-testinterview.component.html',
  styleUrls: ['./dashboard-testinterview.component.css']
})
export class DashboardTestinterviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
