import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-notification',
  templateUrl: './dashboard-notification.component.html',
  styleUrls: ['./dashboard-notification.component.css']
})
export class DashboardNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
