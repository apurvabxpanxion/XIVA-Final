import { Component, OnInit, HostListener } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  private fixed: boolean = false; 
  constructor() {

   }

  ngOnInit() {
   
  }
   
  @HostListener("window:scroll", [])
  onWindowScroll() {

    const number = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    if (number > 100) {
       this.fixed = true;
    }
    else {
      this.fixed = false;
    }

  }
  
 
}
